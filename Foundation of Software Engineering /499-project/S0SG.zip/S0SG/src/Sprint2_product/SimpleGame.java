package Sprint2_product;

public class SimpleGame extends SosBoard {
	
	public SimpleGame(int size) {
		super(size);
	}
	
	public void checkForWin() {
		
		
		
	}
}

package Sprint2_product;

import java.util.ArrayList;

import java.util.List;
import java.util.Random;



public abstract class SosBoard {
    
    public int size;
    public enum Cell {EMPTY, S, O}
   
    public final List<int[]> redWinningPatterns;
    public final List<int[]> blueWinningPatterns;

    protected Cell[][] grid;
    protected char turn;
    protected int totalMoves, bluePoints, redPoints;
    Random rng = new Random();

    public SosBoard(int size) {
    	this.size = size;
        
        redWinningPatterns = new ArrayList<>();
        blueWinningPatterns = new ArrayList<>();
        initBoard();
    }

    public void initBoard() {
        grid = new Cell[size][size];

        for (int row = 0; row < size; ++row) {
            for (int col = 0; col < size; ++col) {
                grid[row][col] = Cell.EMPTY;
            }
        }
     
       
        turn = 'B';
        totalMoves = 0;
        bluePoints = 0;
        redPoints = 0;
    }

    public Cell getCell(int row, int column) {
        if (row >= 0 && row < size && column >= 0 && column < size) {
            return grid[row][column];
        } else {
            return null;
        }
    }

    public void setCell(int row, int column, Cell cell) {
        if (row >= 0 && row < size && column >= 0 && column < size) {
            grid[row][column] = cell;
        }
    }
    
    public char getTurn() {
        return turn;
    }	
    
    public void setTurn(char t) {
		t = turn;
	}

  
    
  
    
   

  
	
 
    
    
	public int checkSos(int row, int col)
	{
        //bound check/empty check
        Cell cell = getCell(row, col);
        if(cell == null || cell==Cell.EMPTY) return 0;

        List<int[]> winningPatterns = (getTurn()=='R') ? redWinningPatterns : blueWinningPatterns;

        int points = 0;
        if(cell == Cell.O){
            if(getCell(row, col-1)==Cell.S && getCell(row, col+1)==Cell.S){
                winningPatterns.add(new int[]{row, col-1, row, col+1});
                points+=1;
            }
            if(getCell(row-1, col)==Cell.S && getCell(row+1, col)==Cell.S){
                winningPatterns.add(new int[]{row-1, col, row+1, col});
                points+=1;
            }
            if(getCell(row-1, col-1)==Cell.S && getCell(row+1, col+1)==Cell.S){
                winningPatterns.add(new int[]{row-1, col-1, row+1, col+1});
                points+=1;
            }
            if(getCell(row-1, col+1)==Cell.S && getCell(row+1, col-1)==Cell.S){
                winningPatterns.add(new int[]{row-1, col+1, row+1, col-1});
                points+=1;
            }
        }
        else if(cell == Cell.S){
            if(getCell(row, col-1)==Cell.O && getCell(row, col-2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row, col-2});
                points+=1;
            }
            if(getCell(row, col+1)==Cell.O && getCell(row, col+2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row, col+2});
                points+=1;
            }
            if(getCell(row-1, col)==Cell.O && getCell(row-2, col)==Cell.S){
                winningPatterns.add(new int[]{row, col, row-2, col});
                points+=1;
            }
            if(getCell(row+1, col)==Cell.O && getCell(row+2, col)==Cell.S){
                winningPatterns.add(new int[]{row, col, row+2, col});
                points+=1;
            }
            if(getCell(row-1, col-1)==Cell.O && getCell(row-2, col-2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row-2, col-2});
                points+=1;
            }
            if(getCell(row+1, col+1)==Cell.O && getCell(row+2, col+2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row+2, col+2});
                points+=1;
            }
            if(getCell(row-1, col+1)==Cell.O && getCell(row-2, col+2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row-2, col+2});
                points+=1;
            }
            if(getCell(row+1, col-1)==Cell.O && getCell(row+2, col-2)==Cell.S){
                winningPatterns.add(new int[]{row, col, row+2, col-2});
                points+=1;
            }
        }
		return points;
	}

    public abstract void checkForWin();
    
 
    	
    
   
}





	











	
	


	


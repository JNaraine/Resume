package sprint1_test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import sprint1_product.EmptyBoard;

class EmptyBoardTest {
	
	private EmptyBoard boardTest = new EmptyBoard();

	@Test
	void test() {
		for (int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				assertEquals("", boardTest.getCell(row, col), 0);
			}
		}
		assertEquals("", boardTest.getTurn(),'S');
	}

}

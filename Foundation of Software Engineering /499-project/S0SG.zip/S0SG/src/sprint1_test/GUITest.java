package sprint1_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GUITest {

	@Test
	void test() {
		

		new GUITest();
	}

}

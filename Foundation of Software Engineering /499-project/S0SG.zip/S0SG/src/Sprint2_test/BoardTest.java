package Sprint2_test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Sprint2_product.Board;

class BoardTest {

	
	private Board board = new Board();
	@Test
	void testNewBoard() {
		for(int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				assertEquals("", board.getCell(row, col), 0);
				
			}
		}
	}

	@Test
	public void testInvalidRow() {
		assertEquals("", board.getCell(3, 0), -1); 
	}
	@Test
	public void testInvalidColumn() {
		assertEquals("", board.getCell(0, 3), -1); 
	}
}

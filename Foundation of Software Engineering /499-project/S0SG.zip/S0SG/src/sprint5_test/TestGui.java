package sprint5_test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;

import org.junit.jupiter.api.Test;

class TestGui {

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	
	@Test
	void out() {
		 System.out.print("hello");
		    assertEquals("hello", outContent.toString());
	}

}

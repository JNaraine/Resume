package Sprint3_Test;

import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import sprint3_product.Board;

class BoardTest {

	private Board board = new Board();
	
	@Test
	public void testNewBoard() {
		for (int row = 0; row <board.getTotalRow(); ++row) {
			for (int col = 0; col < board.getTotalColumns(); ++col) {
				assertEquals("", board.getCell(row, col), sprint3_product.Board.Cell.EMPTY); 
			}
		}
	}

	@Test
	public void testInvalidRow() {
		assertEquals("", board.getCell(3, 0), null); 
	}
	@Test
	public void testInvalidColumn() {
		assertEquals("", board.getCell(0, 3), null); 
	}
}
